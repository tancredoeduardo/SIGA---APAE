<!-- Button (Double) -->
<br><br><br>
<div class="form-group">
	<label class="col-md-4 control-label" for="idConfirmar"></label>
	<div class="col-md-8">

		<button id="idConfirmar" name="idConfirmar" class="btn btn-success" type="submit">Confirmar</button>
		
		<button type="reset" id="idCancelar" name="idCancelar" class="btn btn-danger" onclick=
		<?php echo "\"location.href="."'".$servidor."/siga';"."\">"; ?>
		Cancelar
		</button>
</div>
</div>
