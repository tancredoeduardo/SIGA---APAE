<?php

session_start();
if((!isset ($_SESSION['login']) == true) and (!isset ($_SESSION['senha']) == true))
{
	session_destroy();
	unset ($_SESSION['login']);
	unset ($_SESSION['senha']);
	unset ($_SESSION['idUsuario']);
	unset ($_SESSION['nome']);
	unset ($_SESSION['idpermissoes']);
	unset ($_SESSION['admin']);
	header('location:telalogin.php');	
}
?>