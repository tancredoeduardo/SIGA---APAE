   <div class="row">

    <div class="col-md-2 form-group">
      <label for="idaluno" class="control-label">ID do Aluno</label>

      <input type="text" name="idaluno" class="form-control input-md" id="idaluno" placeholder="ID" readonly required>
    </div>

    <div class="col-md-10 form-group">
          <label for="nomealuno" class="control-label">Nome do Aluno</label>

      <input type="text" name="nomealuno" class="form-control input-md" id="nomealuno" placeholder="Nome" readonly required>
    </div>


  </div>