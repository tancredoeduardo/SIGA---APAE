<?php
include "cabecalho.php";
include "menu.php";
?>
<title>SIGA APAE</title>
<body style="padding-top:60px; padding-bottom: 30px;">

</body">
<?php  
include "rodape.php";
?>
