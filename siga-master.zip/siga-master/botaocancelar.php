		<button type="reset" id="idCancelar" name="idCancelar" class="btn btn-danger" onclick= 
		<?php echo "\"location.href="."'".$servidor."/siga';"."\">"; ?>
		Cancelar
	</button>

