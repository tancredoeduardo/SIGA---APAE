   <div class="row">

    <div class="col-md-2 form-group">
      <input type="text" name="idaluno" class="form-control input-md" id="idaluno" placeholder="ID" readonly required>
    </div>

    <div class="col-md-8 form-group">
      <input type="text" name="nomealuno" class="form-control input-md" id="nomealuno" placeholder="Selecione o aluno" readonly required>
    </div>

    <div class="col-md-2 form-group">

      <button type="button" class="btn-toggle btn btn-info" data-element="#minhaDiv">Buscar</button>
  
    </div> 

  </div>